package com.myblog.dao;

import com.myblog.entity.SetArtitleLabel;

public interface SetArtitleLabelMapper {
    int deleteByPrimaryKey(Integer articleId);

    int insert(SetArtitleLabel record);

    int insertSelective(SetArtitleLabel record);

    SetArtitleLabel selectByPrimaryKey(Integer articleId);

    int updateByPrimaryKeySelective(SetArtitleLabel record);

    int updateByPrimaryKey(SetArtitleLabel record);
}