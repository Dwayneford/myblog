package com.myblog.dao;

import com.myblog.entity.UserFriends;

public interface UserFriendsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(UserFriends record);

    int insertSelective(UserFriends record);

    UserFriends selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(UserFriends record);

    int updateByPrimaryKey(UserFriends record);
}