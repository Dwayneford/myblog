package com.myblog.dao;

import com.myblog.entity.SetArtitleSortKey;

public interface SetArtitleSortMapper {
    int deleteByPrimaryKey(SetArtitleSortKey key);

    int insert(SetArtitleSortKey record);

    int insertSelective(SetArtitleSortKey record);
}