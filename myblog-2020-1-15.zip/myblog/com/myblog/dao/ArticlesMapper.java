package com.myblog.dao;

import com.myblog.entity.Articles;
import com.myblog.entity.ArticlesWithBLOBs;

public interface ArticlesMapper {
    int deleteByPrimaryKey(Integer articleId);

    int insert(ArticlesWithBLOBs record);

    int insertSelective(ArticlesWithBLOBs record);

    ArticlesWithBLOBs selectByPrimaryKey(Integer articleId);

    int updateByPrimaryKeySelective(ArticlesWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(ArticlesWithBLOBs record);

    int updateByPrimaryKey(Articles record);
}