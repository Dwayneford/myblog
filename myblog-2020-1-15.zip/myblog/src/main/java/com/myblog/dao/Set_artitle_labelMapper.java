package com.myblog.dao;

import com.myblog.entity.Set_artitle_label;

public interface Set_artitle_labelMapper {
    int deleteByPrimaryKey(Integer articleId);

    int insert(Set_artitle_label record);

    int insertSelective(Set_artitle_label record);

    Set_artitle_label selectByPrimaryKey(Integer articleId);

    int updateByPrimaryKeySelective(Set_artitle_label record);

    int updateByPrimaryKey(Set_artitle_label record);
}