package com.myblog.dao;

import com.myblog.entity.User_friends;
import com.myblog.entity.User_friends;

public interface User_friendsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(User_friends record);

    int insertSelective(User_friends record);

    User_friends selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(User_friends record);

    int updateByPrimaryKey(User_friends record);
}