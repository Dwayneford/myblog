package com.myblog.dao;

import com.myblog.entity.Set_artitle_sortKey;


public interface Set_artitle_sortMapper {
    int deleteByPrimaryKey(Set_artitle_sortKey key);

    int insert(Set_artitle_sortKey record);

    int insertSelective(Set_artitle_sortKey record);
}