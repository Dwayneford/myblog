package com.myblog.dao;

import com.myblog.entity.Sorts;
import com.myblog.entity.Sorts;

public interface SortsMapper {
    int deleteByPrimaryKey(Integer sortId);

    int insert(Sorts record);

    int insertSelective(Sorts record);

    Sorts selectByPrimaryKey(Integer sortId);

    int updateByPrimaryKeySelective(Sorts record);

    int updateByPrimaryKeyWithBLOBs(Sorts record);

    int updateByPrimaryKey(Sorts record);
}