package com.myblog.temp;

import com.sun.xml.internal.ws.server.sei.ValueGetter;
import org.mybatis.logging.Logger;
import org.springframework.data.redis.core.StringRedisTemplate;

import javax.annotation.Resource;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class StringRedisTest {
    @Resource
    StringRedisTemplate stringRedisTemplate;

    public static void main(String[] args) {
        StringRedisTest test = new StringRedisTest();
        test.valueAddResitTest();
        test.valueGetResitTest();

    }
    public void valueAddResitTest(){
        stringRedisTemplate.opsForValue().set("key","value");
    }


    public void valueGetResitTest(){
        String value = stringRedisTemplate.opsForValue().get("key");
        System.out.println(value);
    }


    public void valueDelResitTest(){
        stringRedisTemplate.delete("key");
    }


    public void valueTimeoutResitTest(){
        stringRedisTemplate.opsForValue().set("timeStep", new Date().getTime()+"", 2 , TimeUnit.MINUTES);
    }
}
