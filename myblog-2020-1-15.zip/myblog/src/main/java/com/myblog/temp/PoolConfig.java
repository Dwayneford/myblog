package com.myblog.temp;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class PoolConfig {
    public void setPoolConfig(){
        JedisPoolConfig poolConfig = new JedisPoolConfig();
// 最大空闲数
        poolConfig.setMaxIdle(50);
// 最大连接数
        poolConfig.setMaxTotal(100);
// 最大等待毫秒数
        poolConfig.setMaxWaitMillis(20000);
// 使用配置创建连接池
        JedisPool pool = new JedisPool(poolConfig, "localhost");
// 从连接池中获取单个连接
        Jedis jedis = pool.getResource();
// 如果需要密码
//jedis.auth("password");

    }
}
