package com.myblog.service;

import com.myblog.entity.Articles;
import com.myblog.util.Pager;




public interface IArticlesService {

    int deleteByPrimaryKey(int articleId);

    int insert(Articles record);

    int insertSelective(Articles record);

    Articles selectByPrimaryKey(Integer articleId);

    int updateByPrimaryKeySelective(Articles record);

    int updateByPrimaryKey(Articles record);

    /**
     * 分页查询方法
     */
    public Pager<Articles> findByPager(int page, int size) ;

    public long count();

//    Redis的方法!

    /**
     * 通过id查询文章
     * @param id
     * @return
     */
    Articles findArticlesById(Integer id);

    /**
     * 通过Redis保存文章
     * @param articles
     * @return
     */
    int saveArticles( Articles articles);

    /**
     * 通过Redis更新文章
     * @param articles
     * @return
     */
    int updateArticles(Articles articles);

    /**
     * 利用Redis通过文章id删除该文章
     * @param id
     * @return
     */
    int deleteArticles(Integer id );


}
