package com.myblog.service.ServiceImpl;

import com.myblog.dao.ArticlesMapper;
import com.myblog.entity.Articles;
import com.myblog.service.IArticlesService;
import com.myblog.util.Pager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;


@Service("articlesService")
public class ArticlesServiceImpl implements IArticlesService {


    @Autowired
    private ArticlesMapper articlesDao ;
//定义日志对象存放方法，操作日志信息
    private static final Logger LOGGER = LoggerFactory.getLogger(ArticlesServiceImpl.class);
//redis操作的客户端
    @Autowired
    private RedisTemplate redisTemplate ;

    /*
    利用Redis操作数据库，业务逻辑实现
     */
    @Override
    public Articles findArticlesById(Integer id) {
        System.out.println("findArticlesById方法开始!ID="+id);
        String key = id +"";
        //获取Redis的操作对象
        ValueOperations operations = redisTemplate.opsForValue();
        //判断该对象在缓存中是否存在
        Boolean bool = redisTemplate.hasKey(key);
        System.out.println(bool);
        //缓存存在的情况,直接获取
        if (bool){
            Articles articles = (Articles)operations.get(key);
            LOGGER.info("ArticlesServiceImpl.findArticlesById()从Redis缓存中查询了对象："+articles.toString());
            return articles ;
        }
        //缓存中不存在的情况下,从数据库查询，再放到缓存中
        Articles articles = articlesDao.selectByPrimaryKey(id);

        operations.set(key, articles,10, TimeUnit.HOURS);
        LOGGER.info("ArticlesServiceImpl.findArticlesById()向Redis缓存中插入了对象："+articles.toString());

        return articles;
    }

    @Override
    public int saveArticles(Articles articles) {
        return articlesDao.insert(articles);
    }

    @Override
    public int updateArticles(Articles articles) {
        //修改逻辑：数据库修改，再查看Redis中有没有，有就先删除后添加
        int ret = articlesDao.updateByPrimaryKeySelective(articles);
        String key = articles.getArticleId()+"";
        boolean hasKey = redisTemplate.hasKey(key);
        if (hasKey) {
            redisTemplate.delete(key);
            LOGGER.info("CityServiceImpl.updateCity():从缓存中删除该文章:"+articles.getArticleTitle());
            //查询的时候会存入一次,所以此处无需添加
        }
        return ret;
    }

    @Override
    public int deleteArticles(Integer id) {
        int ret = articlesDao.deleteByPrimaryKey(id);
        String key = id+"";
        boolean hasKey = redisTemplate.hasKey(key);
        if (hasKey) {
            redisTemplate.delete(key);
            LOGGER.info("CityServiceImpl.deleteCity():从缓存中删除该文章ID ="+id);
        }
        return ret;
    }


//普通的service方法

    @Override
    public Articles selectByPrimaryKey(Integer articleId) {
        System.out.println("selectByPrimaryKey开始,ID="+articleId);
        return articlesDao.selectByPrimaryKey(articleId);
    }
    @Override
    public int deleteByPrimaryKey(int articleId) {
        return 0;
    }

    @Override
    public int insert(Articles record) {
        return 0;
    }

    @Override
    public int insertSelective(Articles record) {

        return 0;
    }

    @Override
    public int updateByPrimaryKeySelective(Articles record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(Articles record) {
        return 0;
    }

    @Override
    public Pager<Articles> findByPager(int page, int size) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("page", (page-1)*size);
        params.put("size", size);
        Pager<Articles> pager = new Pager<Articles>();
        List<Articles> list = articlesDao.selectArticlesPage(params);
        pager.setRows(list);
        pager.setTotal(articlesDao.count());
        return pager;
    }


    @Override
    public long count() {
        return articlesDao.count();
    }

}