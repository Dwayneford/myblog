package com.myblog.controller;

import com.myblog.entity.Articles;
import com.myblog.service.IArticlesService;
import com.myblog.util.Pager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class pageController {
    @Autowired
    private IArticlesService articlesService ;

    int pageNum =1 ;


    @RequestMapping("")
    public ModelAndView Index(){
        return new ModelAndView("redirect:dwayneford");
    }
    @RequestMapping("dwayneford")
    public String index(Model model){
        //每页显示条数
        String  pageNum="1";
        //每页显示条数
        int size = 3 ;
        Pager<Articles> pager = articlesService.findByPager(Integer.parseInt(pageNum), size);
        List<Articles>  list = pager.getRows();
        model.addAttribute("list", list);
        int pagenum=Integer.parseInt(pageNum);
        model.addAttribute("pageNum",pagenum);
        int totalPages ;
        if (pager.getTotal()%size != 0){
            totalPages = (int) (pager.getTotal()/size) + 1;
        }else {
            totalPages = (int) (pager.getTotal()/size);
        }
        model.addAttribute("totalPages",totalPages);
        model.addAttribute("totalElements",pager.getTotal());
        return "index";
    }

    @GetMapping(value="dwayneford/{pageTo}")
    public String ArticlePage(@RequestParam(value="pageTo",required = false,defaultValue = "1")String pageTo , Model model){
        int totalPages ;
        //每页显示条数
        int size = 3 ;
        //总页数
        if (articlesService.count()%size != 0){
            totalPages = (int) (articlesService.count()/size) + 1;
        }else {
            totalPages = (int) (articlesService.count()/size);
        }
        //上下页跳转判断
        if ("down".equals(pageTo) && pageNum<totalPages){
            pageNum ++ ;
        }else if("up".equals(pageTo) && pageNum>1){
            pageNum -- ;
        }else if ("first".equals(pageTo)){
            pageNum = 1 ;
        } else if ("last".equals(pageTo)){
            pageNum = totalPages ;
        }
        Pager<Articles> pager = articlesService.findByPager(pageNum, size);

        List<Articles>  list = pager.getRows();
        model.addAttribute("list", list);

        model.addAttribute("pageNum",pageNum);


        model.addAttribute("totalPages",totalPages);
        model.addAttribute("totalElements",pager.getTotal());

        return "index::table_refresh";
    }





 ///////////////////////////////////////////////////////////////





    @RequestMapping("ArticlePage")
    public String ArticlePage1(Model model){
        //每页显示条数
        String  pageNum="1";
        //每页显示条数
        int size = 3 ;
        Pager<Articles> pager = articlesService.findByPager(Integer.parseInt(pageNum), size);
        List<Articles>  list = pager.getRows();
        model.addAttribute("list", list);
        int pagenum=Integer.parseInt(pageNum);
        model.addAttribute("pageNum",pagenum);
        int totalPages ;
        if (pager.getTotal()%size != 0){
            totalPages = (int) (pager.getTotal()/size) + 1;
        }else {
            totalPages = (int) (pager.getTotal()/size);
        }
        model.addAttribute("totalPages",totalPages);
        model.addAttribute("totalElements",pager.getTotal());
        return "temp/article";
    }
    @GetMapping(value="ArticlePage/{pageNum}")
    public String ArticlePage2(@RequestParam(value="pageNum",required = false,defaultValue = "1")String pageNum , Model model){
        if(pageNum==null ){
            pageNum="1";
        }
        //每页显示条数
        int size = 3 ;
        Pager<Articles> pager = articlesService.findByPager(Integer.parseInt(pageNum), size);
        List<Articles>  list = pager.getRows();
        model.addAttribute("list", list);
        int pagenum=Integer.parseInt(pageNum);
        model.addAttribute("pageNum",pagenum);
        int totalPages ;
        if (pager.getTotal()%size != 0){
            totalPages = (int) (pager.getTotal()/size) + 1;
        }else {
            totalPages = (int) (pager.getTotal()/size);
        }

        model.addAttribute("refresh", "我不会被刷新");

        model.addAttribute("totalPages",totalPages);
        model.addAttribute("totalElements",pager.getTotal());
        System.out.println(totalPages);
        // 在标签里加入：th:fragment="table_refresh"
        //::table_refresh
        return "temp/article::table_refresh";
    }

/////////////////////////////////////////////////////
//Redis
    @RequestMapping("articles")
    public String getArticle(Model model){
        //普通数据库查询
        //selectByPrimaryKey(10001)
//        Articles articles = articlesService.selectByPrimaryKey(10001);

        //Redis查询
        Articles articles = articlesService.findArticlesById(10001);
        model.addAttribute("articles", articles);
        return "temp/article";
    }
}
