package com.myblog.entity;

import java.io.Serializable;
import java.util.Date;

public class Articles implements Serializable {
    private static final long serialVersionUID = -1L;
    private Integer articleId; //文章ID

    private Integer userId; //用户id

    private Integer articleViews; //浏览量

    private Integer articleCommentCount; // 评论总数

    private String articleTitle ;  //文章标题

    private String articleContent;  //博文内容

    private Date articleDate ;  //博文日期

    private int articleLikeCount ;      //点赞数

    private String articlePic ;     //文章图片

    public int getArticleLikeCount() {
        return articleLikeCount;
    }

    public void setArticleLikeCount(int articleLikeCount) {
        this.articleLikeCount = articleLikeCount;
    }

    public Date getArticleDate() {
        return articleDate;
    }

    public void setArticleDate(Date articleDate) {
        this.articleDate = articleDate;
    }

    public Integer getArticleId() {
        return articleId;
    }

    public void setArticleId(Integer articleId) {
        this.articleId = articleId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getArticleViews() {
        return articleViews;
    }

    public void setArticleViews(Integer articleViews) {
        this.articleViews = articleViews;
    }

    public Integer getArticleCommentCount() {
        return articleCommentCount;
    }

    public void setArticleCommentCount(Integer articleCommentCount) {
        this.articleCommentCount = articleCommentCount;
    }

    public String getArticleTitle() {
        return articleTitle;
    }

    public void setArticleTitle(String articleTitle) {
        this.articleTitle = articleTitle;
    }

    public String getArticleContent() {
        return articleContent;
    }

    public void setArticleContent(String articleContent) {
        this.articleContent = articleContent;
    }

    public Articles(Integer articleId, Integer userId, Integer articleViews, Integer articleCommentCount, String articleTitle, String articleContent, Date articleDate, int articleLikeCount, String articlePic) {
        this.articleId = articleId;
        this.userId = userId;
        this.articleViews = articleViews;
        this.articleCommentCount = articleCommentCount;
        this.articleTitle = articleTitle;
        this.articleContent = articleContent;
        this.articleDate = articleDate;
        this.articleLikeCount = articleLikeCount;
        this.articlePic = articlePic;
    }

    public Articles() {
    }

    public String getArticlePic() {
        return articlePic;
    }

    public void setArticlePic(String articlePic) {
        this.articlePic = articlePic;
    }

    @Override
    public String toString() {
        return "Articles{" +
                "articleId=" + articleId +
                ", userId=" + userId +
                ", articleViews=" + articleViews +
                ", articleCommentCount=" + articleCommentCount +
                ", articleTitle='" + articleTitle + '\'' +
                ", articleContent='" + articleContent + '\'' +
                ", articleDate=" + articleDate +
                ", articleLikeCount=" + articleLikeCount +
                ", articlePic='" + articlePic + '\'' +
                '}';
    }
}